// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyD4lBhAs90EqiJcWqqC_YqIz_JZDqiKViI",
  authDomain: "blockchainvoting-5e2b0.firebaseapp.com",
  projectId: "blockchainvoting-5e2b0",
  storageBucket: "blockchainvoting-5e2b0.appspot.com",
  messagingSenderId: "326374693287",
  appId: "1:326374693287:web:31b7b65563c46bd2f97e82",
  measurementId: "G-8C0XTJ6K4X"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
